
context.setVariable("error.header.Content-Type", "application/json" );

var err = context.getVariable("error.content") || "{}";
var errJson, fault_name, fault_message, fault_code, fault_reason, fault_status_code;

fault_name = context.getVariable("fault.name");

if( err == "{}"){
    fault_code = fault_name;
    fault_reason = "Error on calling Backend";
}else{
    errJson = JSON.parse(err);
    
    if( errJson.fault && errJson.fault.detail ){
        fault_code = errJson.fault.detail.errorcode;
        fault_reason = errJson.fault.faultstring;
        
    }else{
        fault_code = fault_name;
        fault_reason = errJson;
    }
}


gemini = "Internal Error happened. Ask Administrator!";

switch( fault_code){
    case "policies.ratelimit.QuotaViolation" :
        //fault_message = "Quota exceeded. Ask Administrator!";
        fault_message = "Quota exceeded. Please try again later.";
        fault_status_code = 401;
        break;
    case "steps.regexprotection.ThreatDetected" :
        fault_message = "Disallowd words exist. Please try again!";
        fault_status_code = 401;
        break;
    case "steps.extractvariables.InvalidJSONPath" :
        fault_message = "Error in Request Data. model, prompt, apikey required!";
        fault_status_code = 400;
        context.setVariable("llm.model", "Error");
        context.setVariable("llm.query", "Error");
        break;
    case "steps.extractvariables.ExecutionFailed" :
        fault_message = "Syntax error on Request JSON";
        fault_status_code = 400;
        context.setVariable("llm.model", "Error");
        context.setVariable("llm.query", "Error");
        break;
    case "steps.extractvariables.UnableToCast" :
        fault_message = "Error in Request Data. model, prompt, apikey required!";
        fault_status_code = 400;
        context.setVariable("llm.model", "Error");
        context.setVariable("llm.query", "Error");
        break;        
    case "oauth.v2.InvalidApiKey" :
        fault_message = "Unregistered API Key!";
        fault_status_code = 401;
        break;      
    case "steps.oauth.v2.FailedToResolveAPIKey" :
        fault_message = "Unable to resolve API Key!";
        fault_status_code = 400;
        break;           
    case "oauth.v2.InvalidApiKeyForGivenResource" :
        fault_message = "API Key No permission on the given resources";
        fault_status_code = 401;
        break;          
    case "steps.servicecallout.ExecutionFailed" :
        fault_message = "Error executing ServiceCallout"
        fault_status_code = 500;
        break;
    case "ErrorResponseCode" :
        fault_message = "Error response from Backend";
        fault_status_code = 500;
        break;        
    case "messaging.adaptors.http.flow.ErrorResponseCode" :
        fault_message = "Error on calling Backend";
        fault_status_code = 500;
        break;           
    case "steps.javascript.ScriptExecutionFailed" :
        fault_message = "Error executing Javascript";
        fault_status_code = 500;
        break;        
    case "keymanagement.service.invalid_access_token" :
        fault_message = "Invalid Access Token";
        fault_status_code = 401;
        gemini = "Access Token was Invalid."
        break;        
    case "keymanagement.service.access_token_not_approved" :
        fault_message = "Revoked Access Token Submitted";
        fault_status_code = 401;
        gemini = "Revoked Access Token Submitted."
        break;           
    case "keymanagement.service.access_token_expired" :
        fault_message = "Access Token Expired";
        fault_status_code = 401;
        gemini = "Access Token was Expired."
        break;  
    case "steps.raisefault.RaiseFault" :
        fault_message = "Invalid Request Message";
        fault_status_code = 400;
        break;
    default :
        fault_message = "Internal Error happened. Ask Administrator!";
}

//print("faultname : " + faultname);
//print("err_payload : " + JSON.stringify(err_payload));

var kst = crypto.dateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",'GMT+9', context.getVariable("client.received.start.timestamp"));
context.setVariable("imagen.kstimestamp", kst);

var err_response = {};
err_response["error"] = {};
err_response["error"]["message"] = fault_message;
err_response["error"]["faultcode"] = fault_code
err_response["error"]["detail"] = fault_reason;

err_response["gemini"] = gemini;


context.setVariable("error.content", JSON.stringify(err_response));    
context.setVariable("imagen.query", "Error - " + fault_message);   
context.setVariable("error.status.code", fault_status_code );
 


errJson.fault.message = fault_message;
context.setVariable("error.content", JSON.stringify(err_response));    
context.setVariable("imagen.query", "Error - " + fault_message);   
context.setVariable("error.status.code", fault_status_code );
   