var user_prompt = context.getVariable("user.prompt");
//var gemini_promt = context.getVariable("llm.query");

// var query = "You are an assistant who enrich the prompt for Imagen3. ";
// query += "Please enhance the prompts to be as descriptive as possible so that Imagen3 can generate images well, referring to the information in <context>. ";
// query += "Please write between <> in English .";

var info ='<context>';
info += user_prompt;
info += '</context>';

context.setVariable("llm.info", info);


 